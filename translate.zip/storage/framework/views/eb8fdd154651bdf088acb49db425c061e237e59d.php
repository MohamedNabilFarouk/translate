<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="material-icons icon-20pt">home</i> Home </a></li>
                            <li class="breadcrumb-item active" aria-current="page">Language</li>
                        </ol>
                    </nav>
                    <h1 class="m-0"> Language </h1>
                </div>
            </div>
        </div>

        <div class="container-fluid page__container">

            <div class="card card-form__body card-body">
                <form method="post" action="<?php echo e(route('language.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('dashboard.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="form-group">
                        <label for="ar_title"> From - To</label>
                        <input  name="from_to" type='text' class="form-control" placeholder="Ex: English - Arabic" value="<?php echo e(old('from_to')); ?>">
                    </div>
       
                    

                    <div class="form-group">
                    <label for="ar_title"> price</label>
                        <input class="form-control" type="number" name="price" value="<?php echo e(old('price')); ?>">
                    </div>
                    <div class="form-group">
                    <label for="ar_title"> extra copy price</label>
                        <input class="form-control" type="number" name="extra_copy_price" value="<?php echo e(old('extra_copy_price')); ?>">
                    </div>
                    


                    <div class="text-right mb-5">
                        <input type="submit" name="add" class="btn btn-success" value="add">
                    </div>
                </form>
            </div>
        </div>
        <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel_volcano_projects\guruma\translate\resources\views/dashboard/language/create.blade.php ENDPATH**/ ?>