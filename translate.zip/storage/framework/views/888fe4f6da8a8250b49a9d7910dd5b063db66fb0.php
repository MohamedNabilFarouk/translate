

<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="material-icons icon-20pt">home</i> Home </a></li>
                            <li class="breadcrumb-item active" aria-current="page">translated files</li>
                        </ol>
                    </nav>
                    <h1 class="m-0"> translated_files </h1>
                </div>
            </div>
        </div>

        <div class="container-fluid page__container">

            <div class="card card-form__body card-body">
                <form method="post" action="<?php echo e(route('translated_files.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('dashboard.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="form-group">
                        <label for="title"> Title</label>
                        <input  name="title" type='text' class="form-control"  value="<?php echo e(old('title')); ?>">
                    </div>
       
                    <div class="form-group">
                        <label for="des"> Description</label>
                        <textarea  name="des" class="form-control"><?php echo e(old('des')); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="title"> Beneficiary Name</label>
                        <input  name="beneficiary_name" type='text' class="form-control"  value="<?php echo e(old('beneficiary_name')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="title"> Beneficiary Phone</label>
                        <input  name="phone" type='text' class="form-control"  value="<?php echo e(old('phone')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="team_id"> Trasnlator</label>
                        <select class="form-control"  name='team_id' required>
                            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value='<?php echo e($t->id); ?>' ><?php echo e($t->name); ?>-(<?php echo e($t->code); ?>)</option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                  </select>
                    </div>
                    
                    <div class="form-group">
                        <input class="image_name" type="file" name="image[]" value="" multiple>
                    </div>
                    <div class="form-group">
                        <label> Image </label>
                        <div class="dropzone" id="mainphoto"></div>
                    </div>


                    <div class="form-group">
                        <input class="image_name" type="file" name="file" value="">
                    </div>
                    <div class="form-group">
                        <label> Translated File </label>
                        <div class="dropzone" id="mainphoto"></div>
                    </div>


                    <div class="text-right mb-5">
                        <input type="submit" name="add" class="btn btn-success" value="add">
                    </div>
                </form>
            </div>
        </div>
        <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel_volcano_projects\guruma\translate\resources\views/dashboard/translated_files/createOnPaper.blade.php ENDPATH**/ ?>