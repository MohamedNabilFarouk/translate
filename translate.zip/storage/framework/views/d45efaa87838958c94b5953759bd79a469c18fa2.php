

<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="material-icons icon-20pt">home</i> Home </a></li>
                            <li class="breadcrumb-item active" aria-current="page">Appointment For <?php echo e($office->office); ?></li>
                        </ol>
                    </nav>
                    <h1 class="m-0"> Appointment For <?php echo e($office->office); ?> </h1>
                </div>
            </div>
        </div>

        <div class="container-fluid page__container">

            <div class="card card-form__body card-body">
                <form method="post" action="<?php echo e(route('appointment.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('dashboard.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

       <input type='hidden' name='office_id' value='<?php echo e($office->id); ?>'>
                    <div class="form-group">
                    <label for="ar_title"> appointment</label>
                        <input class="form-control" type="text" name="appointment" value="<?php echo e(old('appointment')); ?>" required>
                    </div>
                   
                    


                    <div class="text-right mb-5">
                        <input type="submit" name="add" class="btn btn-success" value="add">
                    </div>
                </form>
            </div>
        </div>
        <!-- // END drawer-layout__content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel_volcano_projects\guruma\translate\resources\views/dashboard/appointment/create.blade.php ENDPATH**/ ?>