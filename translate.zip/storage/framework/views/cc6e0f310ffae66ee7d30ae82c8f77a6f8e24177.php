<!DOCTYPE html>
<html lang="<?php echo e(session('lang')); ?>" dir="<?php echo e(session('lang') == 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Translate - Dashboard </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">




    <!-- Perfect Scrollbar -->
    <link type="text/css" href="<?php echo e(asset('dashboard/vendor/perfect-scrollbar.css')); ?>" rel="stylesheet">

   


        <link type="text/css" href="<?php echo e(asset('dashboard/css/app.css')); ?>" rel="stylesheet">
        <link type="text/css" href="<?php echo e(asset('dashboard/css/vendor-fontawesome-free.css')); ?>" rel="stylesheet">
        <link type="text/css" href="<?php echo e(asset('dashboard/css/vendor-material-icons.css')); ?>" rel="stylesheet">
        <link type="text/css" href="<?php echo e(asset('dashboard/css/vendor-flatpickr.css')); ?>" rel="stylesheet">
        <link type="text/css" href="<?php echo e(asset('dashboard/css/vendor-flatpickr-airbnb.css')); ?>" rel="stylesheet">
        <link type="text/css" href="<?php echo e(asset('dashboard/css/vendor-dropzone.css')); ?>" rel="stylesheet">
  


    <link href="<?php echo e(asset('dashboard/css/noty.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('dashboard/js/noty.js')); ?>" type="text/javascript"></script>
    <link href="<?php echo e(asset('dashboard/css/sunset.css')); ?>" rel="stylesheet">



    <?php echo $__env->yieldPushContent('admin_styles'); ?>
</head>

<body class="layout-default">

<div class="preloader"></div>

<div class="mdk-header-layout js-mdk-header-layout">
    
    <?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <div class="mdk-header-layout__content">
        <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
            <?php echo $__env->make('dashboard.partials.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('dashboard.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(asset('dashboard/vendor/jquery.min.js')); ?>"></script>

<!-- Bootstrap -->
<script src="<?php echo e(asset('dashboard/vendor/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/vendor/bootstrap.min.js')); ?>"></script>

<!-- Perfect Scrollbar -->
<script src="<?php echo e(asset('dashboard/vendor/perfect-scrollbar.min.js')); ?>"></script>

<!-- DOM Factory -->
<script src="<?php echo e(asset('dashboard/vendor/dom-factory.js')); ?>"></script>

<!-- MDK -->
<script src="<?php echo e(asset('dashboard/vendor/material-design-kit.js')); ?>"></script>

<!-- App -->
<script src="<?php echo e(asset('dashboard/js/toggle-check-all.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/check-selected-row.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/dropdown.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/sidebar-mini.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/app.js')); ?>"></script>




<script type="text/javascript" src="<?php echo e(asset('dashboard/vendor/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/custom/image_preview.js')); ?>"></script>

<!-- Flatpickr -->
<script src="<?php echo e(asset('dashboard/vendor/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/flatpickr.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard/vendor/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/dropzone.js')); ?>"></script>

<!-- Global Settings -->
<script src="<?php echo e(asset('dashboard/js/settings.js')); ?>"></script>

<!-- Moment.js -->
<script src="<?php echo e(asset('dashboard/vendor/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/vendor/moment-range.js')); ?>"></script>


<script src="<?php echo e(asset('dashboard/vendor/Chart.min.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard/js/charts.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/chartjs-rounded-bar.js')); ?>"></script>

<!-- Chart Samples -->
<script src="<?php echo e(asset('dashboard/js/page.dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/progress-charts.js')); ?>"></script>


<script type="text/javascript">
    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        $(document).on('click', '.delete', function (e) {
            var that = $(this);
            e.preventDefault();
            var n = new Noty({
                text: "Confirm deleting record",
                killer: true,
                buttons: [
                    Noty.button('Yes', 'btn btn-success mr-2', function () {
                        that.closest('form').submit();
                    }),
                    Noty.button('No', 'btn btn-danger', function () {
                        n.close();
                    })
                ]
            });
            n.show();
        });
    });

    CKEDITOR.config.language =  "<?php echo e(app()->getLocale()); ?>";
</script>
<?php echo $__env->yieldPushContent('admin_scripts'); ?>

</body>

</html>
<?php /**PATH E:\laravel_volcano_projects\guruma\translate\resources\views/dashboard/layouts/app.blade.php ENDPATH**/ ?>